class Subject {
  constructor(name) {
    this.name = name;
  }
  getSubjectName() {
    return `${this.name}`;
  }
}
